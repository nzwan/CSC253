﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Nicholas A. Zwan
//CSC 253
//M2HW2
//This program calculates the average of a string accepted for input. 

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            StandardMessages.DisplayMainMenu();
        }
    }
}

