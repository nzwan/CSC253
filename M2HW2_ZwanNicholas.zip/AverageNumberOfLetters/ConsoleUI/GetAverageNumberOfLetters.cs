﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class GetAverageNumberOfLetters
    {
        public static void AverageLetter()
        {
            Console.WriteLine("Enter as string to be averaged.");
            string input = Console.ReadLine();
            var separators = new[] { ' ', '.' };
            var average = input.Split(separators, StringSplitOptions.RemoveEmptyEntries)
                      .Select(x => x.Length).Average();
            Console.WriteLine("The average of that string is " + average);
            Console.ReadLine();
        }
    }
}

