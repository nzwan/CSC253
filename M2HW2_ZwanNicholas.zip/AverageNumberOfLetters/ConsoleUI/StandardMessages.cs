﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class StandardMessages
    {
        public static void DisplayMainMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine("1. Enter a string to calculate the average for.");
                Console.WriteLine("2. Exit");
                Console.Write("1/2 =>");
                string input = Console.ReadLine();



                if (input == "1")
                {
                    GetAverageNumberOfLetters.AverageLetter();

                }

                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not a valid choice!");
                    Console.WriteLine("");
                }

            } while (exit == false);
        }
    }
}
    

