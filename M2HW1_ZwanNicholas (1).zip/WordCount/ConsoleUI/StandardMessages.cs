﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_UI
{
    class StandardMessages
    {
        public static void DisplayMainMenu()
        {
            bool exit = false;
            do
            {
                Console.WriteLine("1. Get Count words in string info.");
                Console.WriteLine("2. Exit");
                Console.Write("1/2 =>");
                string input = Console.ReadLine();



                if (input == "1")
                {
                    WordCounter.getWordCount();
                }

                else if (input == "2")
                {
                    exit = true;
                }
                else
                { 
                    Console.WriteLine("Not a valid choice!");
                    Console.WriteLine("");
                }

            } while (exit == false);
        }
    }
}

    


            
            
            