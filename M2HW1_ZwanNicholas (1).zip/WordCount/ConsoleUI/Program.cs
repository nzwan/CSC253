﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Nicholas A. Zwan
//CSC 253
//09/15/19
//M2HW1
//This program accepts a string as input and returns the amount of words in it. 


namespace Console_UI
{
    public class Program
    {

        public static void Main(string[] args)

        {

             StandardMessages.DisplayMainMenu();
                
        }
    }
}

            
            
   
            
    

    
