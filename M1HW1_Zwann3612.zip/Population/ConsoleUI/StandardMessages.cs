﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class StandardMessages
    {

        public static void DisplayMenu()
        {
            Console.WriteLine("1. Calculate Hospital Charges.");
            Console.WriteLine("2. Exit");
            Console.Write("1/2 =>");

        }

        public static void DisplayMenuError()
        {
            Console.WriteLine("Not a valid choice!");
            Console.WriteLine("");
            Console.ReadLine();

        }
    }
}
