﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Organismcalc
    {
        public static void calculations()
        {
            


            double organisms = 0;
            double growthPercentage = 0;
            double days = 0;

            string input = Console.ReadLine();
            Console.WriteLine("How many organisms are you starting with?");
            organisms = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the percent by which you want to show growth for >>>");
            growthPercentage = double.Parse(Console.ReadLine());
            Console.WriteLine("Over How many days do you want to show this growth?");
            days = double.Parse(Console.ReadLine());

            string item;
            for (int i = 1; i <= days; i++)
            {
                item = i.ToString() + " " + organisms.ToString();

                organisms += organisms * growthPercentage;

            }

            Console.WriteLine(organisms);
            Console.ReadLine();

        }

    }
}
