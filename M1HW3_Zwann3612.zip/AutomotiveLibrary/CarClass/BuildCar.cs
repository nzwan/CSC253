﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClass
{
    class BuildCar
    {
        public static car GetCarInfo()
        {
            car output = new car();

            Console.Write("what is the year of the car? ==>");
            output.Year = int.Parse(Console.ReadLine());

            Console.WriteLine("what is the make of the car? ==>");
            output.Make = Console.ReadLine();

            Console.WriteLine("");
            return output;

        }
    }
}
    

