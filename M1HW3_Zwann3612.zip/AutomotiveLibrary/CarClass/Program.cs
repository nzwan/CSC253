﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Nicholas Zwan
//CSC 253
//09/01/19
//Program uses classes to create a car object and accelerate or decelerate speed. 
namespace CarClass
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            car car = new car();

            do
            {
                StandardMessages.DisplayMenu();

                switch (Console.ReadLine())
                {
                    case "1":
                        car = BuildCar.GetCarInfo();
                        break;
                    case "2":
                        car.Accelerate();
                        StandardMessages.DisplayCarSpeed(car);
                        break;
                    case "3":
                        car.Brake();
                        StandardMessages.DisplayCarSpeed(car);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        StandardMessages.DisplayMenuError();
                        break;

                }




            } while (exit == false);
        }
    }
}
       
