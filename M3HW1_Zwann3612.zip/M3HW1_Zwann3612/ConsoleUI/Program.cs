﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

//Nicholas A. Zwan
//10/6/19
//This proram writes random numbers to a file that it generates.
//CSC 253


namespace ConsoleUI
{
    class Program
    {
        public static void Main(string[] args)
        {
          
            // Declare variables.
            int randomNumber = 0;
            int number = 0;
            StreamWriter outputFile;

            // Create file.
            outputFile = File.CreateText("RandomNumberList");
            // Create Random
            Random Rand = new Random();

            for (int count = 0; count < number; count++)
            {
                // Get random integers and assign them to randomNumber.
                randomNumber = Rand.Next(1, 200);

                // Write data file.
                Console.WriteLine(randomNumber);
                outputFile.WriteLine(randomNumber);

            }
            Console.WriteLine("Written to file RandomNumberList");
            Console.ReadLine();

            // Close the file 
            outputFile.Close();

            }
        }

    }

        
    
    

