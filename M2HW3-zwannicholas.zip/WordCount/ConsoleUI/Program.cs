﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Nicholas A. Zwan
//CSC 253
//09/15/19
//M2HW3
//This program accepts a string as input and returns the most frequent character in it. Program is autoclosing for some reason.
//The issues have been mostly fixed but I need to figure out how to display the most common character instead of just 
//the count.

namespace Console_UI
{
    class program
    {


        public static void Main(string[] args)

        {
            StandardMessages.DisplayMainMenu();
        }
    }
}
            
             
           


               
        
    


            
            
   
            
    

    
