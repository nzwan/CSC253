﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_UI
{
    class MostCommonOccurence
    {
        public static void commonOccurence()
        { 
        Console.WriteLine("Enter a string to find the most common occurence. ");
        string str = Console.ReadLine();

        int _maxcount = 0;

                foreach (char c in str)
                {
                    int ix = str.IndexOf(c);
        int count = 0;
                    while (ix != -1)
                    {
                        StringBuilder _s = new StringBuilder();
        _s.Append(str);
                        _s[ix] = ' ';
                        str = _s.ToString();

                        count++;

                        ix = str.IndexOf(c);
                        
                        
                    }

                    if (count > _maxcount)
                    {
                        _maxcount = count;
                    }
                }
            
                Console.WriteLine(_maxcount);
                Console.ReadLine();
            }
        }
    


    }

            