﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
    //Nicholas Zwan
    //09/01/19
    //This program generates a total hospital bill 
    //based on values the user enters. 
{
    class BillCalculations
    {
        public static void getBillingInfo()
        {
            double hospitalDays = 0;
            double medicationCharges = 0;
            double surgicalCharges = 0;
            double labCharges = 0;
            double rehabCharges = 0;
            const double dailyCharge = 350.00;

            string input = Console.ReadLine();
            Console.WriteLine("How many days did you spend in the hospital?");
            hospitalDays = double.Parse(Console.ReadLine());
            Console.WriteLine("How much did you pay in medication charges?");
            medicationCharges = double.Parse(Console.ReadLine());
            Console.WriteLine("How much did you pay in surgical charges?");
            surgicalCharges = double.Parse(Console.ReadLine());
            Console.WriteLine("How much did you pay in lab fees?");
            labCharges = double.Parse(Console.ReadLine());
            Console.WriteLine("How much did you pay in physical rehab charges?");
            rehabCharges = double.Parse(Console.ReadLine());

            double calcStayCharges = dailyCharge * hospitalDays;
            double calcMisCharges = medicationCharges + surgicalCharges + labCharges + rehabCharges;
            double calcTotalCharges = calcStayCharges + calcMisCharges;

            Console.WriteLine("Patient, your total bill is $" + calcTotalCharges + " Press any key to continue...");
            Console.ReadLine();
        }

    }
}
