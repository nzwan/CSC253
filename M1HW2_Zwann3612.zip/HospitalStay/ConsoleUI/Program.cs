﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = true;
            do
            {
                StandardMessages.DisplayMenu();
                switch (Console.ReadLine())
                {
                    case "1":
                        BillCalculations.getBillingInfo();
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        StandardMessages.DisplayMenuError();
                        StandardMessages.DisplayMenu();
                        break;
                }

            } while (exit == false);
        }
    }
}
