﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class Inventory //Needed for inventory modules later. 
    {
        private int _weight;
        private int _space;
        private string _name;

        public Inventory()
        {
            Weight = 0;
            Space = 0;
            Name = "null";

        }
    
        public Inventory(int weight, int space, string name)
        {
            Weight = weight;
            Space = space;
            Name = name;

        }

        public int Weight
        {
            get
            {
                return _weight;
            }
            set
            {
                _weight = value;
            }
        }

        public int Space
        {
            get
            {
                return _space;
            }
            set
            {
                _space = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

    }


}
