﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class Troll
    {
        //Used for player class assignment in rooms

            public Troll()
        {
            Name = null;
            AttackPoints = 0;
            HealthPoints = 0;
            Type = null;
        }

        public Troll(string name, int attackPoints, int healthPoints, int ac, string type)
        {
            Name = name;
            AttackPoints = attackPoints;
            HealthPoints = healthPoints;
            Type = type;
        }


        public string Name { get; set; }
        public int AttackPoints { get; set; }
        public int HealthPoints { get; set; }
        public string Type { get; set; }
    }
}


