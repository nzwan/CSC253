﻿using System;
using System.Collections.Generic;
using System.Text;


namespace GameLibrary
{
    class StandardMessages
    {
        public static string welcome()
        {
            string playerClass = null;
            Console.WriteLine("Choose your class 1. Warrior 2.Thief 3. Mage");
            string input = Console.ReadLine();

            if (input == "1")
            {
                playerClass = "Warrior";
            }
            else if (input == "2")
            {
                playerClass = "Thief";
            }
            else if (input == "3")
            {
                playerClass = "Mage";
            }
            else
            {
               Console.WriteLine("Bad input Scum!");
            }
            
            Player player1 = new Player();
            player1.Name = playerClass;
            player1.HealthPoints = 100;
            player1.AttackPoints = 20;

            Inventory inventory = new Inventory();
            inventory.Space = 4;
            inventory.Name = "bag";
            inventory.Weight = 4;

            Console.WriteLine("Welcome to my world " + player1.Name + ".");
            Console.WriteLine("Be wary that you only posess " + player1.HealthPoints + " of life. Use it wisely...");
            Console.WriteLine("The power you wield amounts to " + player1.AttackPoints + ".");
            Console.WriteLine("You must not exceed the strength of your " + inventory.Name + " which is " + inventory.Weight + "\n" +
                "for it will only hold " + inventory.Space + " items. Type help for controls.");
            //DisplayHelpMenu();
            return " ";
        }
        public static string invalidEntry()
        {
            return "Not a valid option. Try again";
        }
        public static string dead()
        {
            return "You are dead! Hope is lost!";
        }
        public static string killEnemy()
        {
            return "Your enemy is vanquished.";
        }
        public static void displayWeapons()
        {
            string[] weapons = { "knife", "lead pipe", "wrench", "candlestick" };


            // Display the weapons in alphabetical order
            Array.Sort(weapons);
            foreach (string weapon in weapons)
            {
                Console.WriteLine(weapon);
            }
        }

        public static void chooseClass()
        {
            //Implement player choice of class.
            string[] playerJob = { "Warrior", "Mage", "Theif" };
        }


        public static void displayPotions()
        {
            string[] potions = { "health tonic", "strength elixir" };
            Array.Sort(potions);
            foreach (string potion in potions)
            {
                Console.WriteLine(potion);
            }
        }
        public static void displayTreasures()
        {
            string[] treasures = { "ruby red slippers", "Excalibur", "tons of gold" };
            Array.Sort(treasures);
            foreach (string treasure in treasures)
            {
                Console.WriteLine(treasure);
            }

        }
        public static void DisplayHelpMenu()
        {
            Console.WriteLine("1. Navigate.\n2. Display potions.\n3. Display Treasures.\n4. Display Weapons.\n5. Exit. Enter 1, 2, 3, 4 or 5. > ");

        }
        public static void passwordRequest() //Password1 allows access to program.
        {

            {

                Console.WriteLine("Enter password to play!");
                string password = Console.ReadLine();
                if (password == "Password1")
                {
                    welcome();
                }
                else
                {
                    Console.WriteLine("Invalid password. Access denied.");
                    passwordRequest();
                }

            }
        }
            
                public static void useHealthPotion()

            {
            string[] potions = { "health tonic", "strength elixir" };
            Array.Sort(potions);
            Console.WriteLine("You quickly drink the " + potions[1] + " and find that you are once again quite strong.");
            
            }
        public static void victoryMessage()
        {
            Console.WriteLine("As you slump against a wall, you see a prize....The exit. Time to go home. ");
        }
        public static void restAreaMessage()
        {
            Console.WriteLine("You have entered a rest area. Be still and calm, as from here on out there is no turning back. " + "\n" +
                "You sit against the cold wall and prepare for your final march. Sleep comes quickly...." + "\n"+
                 "Enter 1 to awaken and continue");
        }
       // public static void attack(int min, int max)
        //{
          //  Random random = new Random();

            //random.Next(min, max);
       // }

    }
}


