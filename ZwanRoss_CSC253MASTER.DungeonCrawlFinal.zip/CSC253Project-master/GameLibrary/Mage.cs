﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    public class Mage
    {
        //Used player class assignment
        public Mage()
        {
            Name = null;
            AttackPoints = 0;
            HealthPoints = 0;
            Type = null;
        }

        public Mage(string name, int attackPoints, int healthPoints, int ac, string type)
        {
            Name = name;
            AttackPoints = attackPoints;
            HealthPoints = healthPoints;
            Type = type;
        }


        public string Name { get; set; }
        public int AttackPoints { get; set; }
        public int HealthPoints { get; set; }
        public string Type { get; set; }
    }
}

