﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary
{
    class Weapon
    {
        //Used for weapon attribute assignment

        public Weapon(string name, int attackPoints, int healthPoints, int ac, string type)
        {
            Name = name;
            AttackPoints = attackPoints;
            HealthPoints = healthPoints;
            Type = type;
        }


        public string Name { get; set; }
        public int AttackPoints { get; set; }
        public int HealthPoints { get; set; }
        public string Type { get; set; }
    }
}

    

